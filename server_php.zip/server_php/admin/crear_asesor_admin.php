<?php
require_once 'db_admin.php';

// Verificar si es admin o super admin
$is_admin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
$is_super_admin = isset($_SESSION['super_admin_logged_in']) && $_SESSION['super_admin_logged_in'] === true;

if (!$is_admin && !$is_super_admin) {
    header('Location: login.php?role=admin');
    exit;
}

$admin_id = $is_super_admin ? $_SESSION['super_admin_id'] : $_SESSION['admin_id'];
$admin_nombre = $is_super_admin ? $_SESSION['super_admin_nombre'] : $_SESSION['admin_nombre'];

$error = $_GET['error'] ?? '';
$success = $_GET['success'] ?? '';

// Obtener cooperativas/bancos desde tabla unidad_bancaria (mismo <select> se
// usa para las 3 pestañas de rol; sirve para filtrar gerentes/supervisores).
$cooperativas = [];
try {
    $stmt = $pdo->query("
        SELECT id, nombre, codigo
        FROM unidad_bancaria
        WHERE activo = 1
        ORDER BY nombre ASC
    ");
    $cooperativas = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error cargando cooperativas: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super_IA - Crear Cuenta (Gerente / Supervisor / Asesor)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --brand-navy: #123a6d;
            --brand-navy-deep: #0a2748;
            --brand-yellow: #ffdd00;
            --brand-yellow-deep: #f4c400;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', 'Segoe UI', sans-serif; background: #f5f7fa; display: flex; min-height: 100vh; }
        .sidebar {
            width: 230px;
            background: linear-gradient(180deg, var(--brand-navy-deep) 0%, var(--brand-navy) 100%);
            color: white;
            padding: 20px 0;
            overflow-y: auto;
            position: sticky;
            height: 100vh;
            top: 0;
            flex-shrink: 0;
        }
        .sidebar-brand { padding: 0 20px 30px; font-size: 18px; font-weight: 800; border-bottom: 1px solid rgba(255,221,0,0.18); margin-bottom: 20px; }
        .sidebar-brand i { margin-right: 10px; color: var(--brand-yellow); }
        .sidebar-section { padding: 0 15px; margin-bottom: 25px; }
        .sidebar-section-title { font-size: 11px; text-transform: uppercase; color: rgba(255,255,255,0.58); letter-spacing: 0.5px; padding: 0 10px; margin-bottom: 10px; font-weight: 600; }
        .sidebar-link { display: flex; align-items: center; gap: 12px; padding: 12px 15px; margin-bottom: 5px; border-radius: 10px; color: rgba(255,255,255,0.82); cursor: pointer; transition: all 0.25s ease; text-decoration: none; font-size: 14px; }
        .sidebar-link:hover { background: rgba(255,221,0,0.12); color: #fff; padding-left: 20px; }
        .sidebar-link.active { background: linear-gradient(90deg, var(--brand-yellow), var(--brand-yellow-deep)); color: var(--brand-navy-deep); font-weight: 700; }
        .main-content { flex: 1; margin-left: 0 !important; display: flex; flex-direction: column; overflow: hidden; min-width: 0; }
        .navbar-custom { background: linear-gradient(135deg, var(--brand-navy-deep), var(--brand-navy)); color: #fff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1); }
        .navbar-custom h2 { margin: 0; font-size: 20px; font-weight: 700; }
        .user-info { display: flex; align-items: center; gap: 15px; }
        .btn-logout { background: var(--brand-yellow); color: var(--brand-navy-deep); border: 1px solid var(--brand-yellow-deep); padding: 8px 15px; border-radius: 5px; cursor: pointer; text-decoration: none; font-weight: 700; }
        .btn-logout:hover { opacity: .9; }
        .content-area { flex: 1; overflow-y: auto; padding: 30px; }
        .form-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,.06); padding: 30px; max-width: 700px; margin: 0 auto; }
        .page-header { margin-bottom: 30px; max-width: 700px; margin-left: auto; margin-right: auto; }
        .page-header h1 { margin: 0; font-size: 26px; font-weight: 700; color: #1f2937; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 8px; color: #1f2937; font-size: 14px; }
        .form-group input, .form-group select { width: 100%; padding: 12px; border: 1px solid #e5e7eb; border-radius: 8px; font-family: 'Inter', sans-serif; font-size: 14px; transition: all 0.3s ease; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #667eea; box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1); }
        .form-group input::placeholder { color: #d1d5db; }
        .form-group small.hint { display: block; margin-top: 6px; color: #9ca3af; font-size: 12px; }
        .row-cols { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .row-cols .form-group { margin-bottom: 0; }
        .role-tabs { display: flex; gap: 8px; margin-bottom: 24px; max-width: 700px; margin-left: auto; margin-right: auto; }
        .role-tab { flex: 1; text-align: center; padding: 12px 10px; border-radius: 10px; border: 2px solid #e5e7eb; background: #fff; cursor: pointer; font-weight: 700; font-size: 13.5px; color: #6b7280; transition: all .2s ease; }
        .role-tab i { display: block; font-size: 18px; margin-bottom: 4px; }
        .role-tab.active { border-color: #667eea; background: rgba(102,126,234,.08); color: #4c3fbf; }
        .file-upload { border: 2px dashed rgba(102, 126, 234, 0.5); border-radius: 12px; padding: 30px; text-align: center; cursor: pointer; transition: all 0.3s ease; background: rgba(102, 126, 234, 0.05); }
        .file-upload:hover { border-color: #667eea; background: rgba(102, 126, 234, 0.1); }
        .file-input-label { cursor: pointer; display: flex; flex-direction: column; align-items: center; gap: 10px; }
        .file-input-label i { font-size: 32px; color: #667eea; }
        .file-input-label div { font-weight: 600; color: #1f2937; }
        .file-input-label small { color: #9ca3af; }
        .file-name { margin-top: 10px; color: #10b981; font-weight: 600; font-size: 13px; display: none; }
        .file-name.show { display: block; }
        .btn-submit { width: 100%; padding: 12px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; font-size: 16px; transition: all 0.3s ease; margin-top: 20px; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4); }
        .btn-back { padding: 8px 16px; background: #e5e7eb; color: #1f2937; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; font-weight: 600; margin-bottom: 20px; display: inline-flex; align-items: center; gap: 8px; }
        .btn-back:hover { background: #d1d5db; }
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
        .alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; }
        .alert-danger { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; }
        .alert-info { background: #eff6ff; border: 1px solid #bfdbfe; color: #1e40af; }
        #credencial { display: none; }
        input[type="file"] { display: none; }
        @media (max-width: 600px) { .row-cols { grid-template-columns: 1fr; } .form-card { padding: 20px; } .role-tabs { flex-direction: column; } }
    </style>
</head>
<body>

<?php if ($is_super_admin): ?>
    <?php $currentPage = 'crear_asesor'; require_once '_sidebar_super_admin.php'; ?>
<?php else: ?>
<!-- SIDEBAR -->
<div class="sidebar">
    <div class="sidebar-brand">
        <i class="fas fa-crown"></i> Super_IA
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-title">Principal</div>
        <a href="index.php" class="sidebar-link">
            <i class="fas fa-home"></i> Dashboard
        </a>
    </div>

    <div class="sidebar-section">
        <div class="sidebar-section-title">Administración</div>
        <a href="crear_asesor_admin.php" class="sidebar-link active">
            <i class="fas fa-user-plus"></i> Crear Cuenta
        </a>
    </div>
</div>
<?php endif; ?>

<!-- MAIN CONTENT -->
<div class="main-content">
    <!-- NAVBAR -->
    <div class="navbar-custom">
        <h2><?php echo $is_super_admin ? '👑' : '🎯'; ?> Super_IA - Crear Cuenta</h2>
        <div class="user-info">
            <div>
                <strong><?php echo htmlspecialchars($admin_nombre); ?></strong><br>
                <small><?php echo $is_super_admin ? 'Super Administrador' : 'Administrador'; ?></small>
            </div>
            <a href="logout.php" class="btn-logout">Cerrar Sesión</a>
        </div>
    </div>

    <!-- CONTENT -->
    <div class="content-area">

        <div class="page-header">
            <a href="index.php" class="btn-back">
                <i class="fas fa-arrow-left"></i> Volver
            </a>
            <h1><i class="fas fa-user-plus me-2"></i>Crear Cuenta Nueva</h1>
        </div>

        <!-- SELECTOR DE ROL -->
        <div class="role-tabs" id="roleTabs">
            <div class="role-tab" data-rol="gerente_general"><i class="fas fa-user-tie"></i>Gerente General</div>
            <div class="role-tab" data-rol="supervisor"><i class="fas fa-user-shield"></i>Supervisor</div>
            <div class="role-tab active" data-rol="asesor"><i class="fas fa-user"></i>Asesor</div>
        </div>

        <div class="form-card">

            <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i><?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>

            <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i>✅ Cuenta creada y activa. Ya puede iniciar sesión.
            </div>
            <?php endif; ?>

            <div class="alert alert-info" style="margin-bottom:0;">
                <i class="fas fa-info-circle me-2"></i>La cuenta se crea <strong>activa de inmediato</strong> — no queda pendiente de aprobación, porque la estás creando tú mismo como administrador.
            </div>
            <div style="height:20px;"></div>

            <form method="POST" action="procesar_crear_asesor_admin.php" enctype="multipart/form-data" novalidate id="formCrear">
                <input type="hidden" name="rol_crear" id="rolCrearInput" value="asesor">

                <!-- COOPERATIVA / BANCO (siempre visible, filtra los selects de abajo) -->
                <h6 style="margin-top: 0; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                    <i class="fas fa-university me-2"></i>Cooperativa / Banco
                </h6>

                <div class="form-group">
                    <label><i class="fas fa-building me-2"></i>Selecciona Cooperativa / Banco</label>
                    <select name="unidad_bancaria_id" id="selectCooperativa" required onchange="onCooperativaChange()">
                        <option value="">-- Selecciona una cooperativa --</option>
                        <?php foreach ($cooperativas as $coop): ?>
                        <option value="<?php echo htmlspecialchars($coop['id']); ?>">
                            <?php echo htmlspecialchars($coop['nombre'] . ' (' . $coop['codigo'] . ')'); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if (empty($cooperativas)): ?>
                    <small style="color: #ef4444;">⚠️ No hay cooperativas registradas. Contacta al administrador.</small>
                    <?php endif; ?>
                </div>

                <!-- GERENTE RESPONSABLE (solo para rol = supervisor) -->
                <div id="seccionGerente" style="display:none;">
                    <h6 style="margin-top: 20px; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                        <i class="fas fa-user-tie me-2"></i>Gerente Responsable
                    </h6>
                    <div class="form-group">
                        <label><i class="fas fa-user-check me-2"></i>Selecciona el Gerente de esta cooperativa</label>
                        <select name="gerente_responsable_id" id="selectGerente">
                            <option value="">-- Primero selecciona una cooperativa --</option>
                        </select>
                        <small class="hint">El supervisor queda bajo la agencia de este gerente. Requerido para poder aprobar/crear la cuenta.</small>
                    </div>
                </div>

                <!-- SUPERVISOR (solo para rol = asesor) -->
                <div id="seccionSupervisor">
                    <h6 style="margin-top: 20px; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                        <i class="fas fa-user-check me-2"></i>Supervisor Asignado
                    </h6>
                    <div class="form-group">
                        <label><i class="fas fa-user-tie me-2"></i>Selecciona Supervisor</label>
                        <select name="id_supervisor" id="selectSupervisor">
                            <option value="">-- Primero selecciona una cooperativa --</option>
                        </select>
                    </div>
                </div>

                <!-- DATOS PERSONALES -->
                <h6 style="margin-top: 30px; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                    <i class="fas fa-user me-2"></i>Datos Personales
                </h6>

                <div class="row-cols">
                    <div class="form-group">
                        <label><i class="fas fa-user me-2"></i>Nombres</label>
                        <input type="text" name="nombres" placeholder="Ej: Juan Carlos" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-user me-2"></i>Apellidos</label>
                        <input type="text" name="apellidos" placeholder="Ej: García López" required>
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-id-card me-2"></i>Cédula de Identidad</label>
                    <input type="text" name="cedula" placeholder="Ej: 1712345678" maxlength="13" required>
                </div>

                <div class="row-cols">
                    <div class="form-group">
                        <label><i class="fas fa-envelope me-2"></i>Correo Electrónico</label>
                        <input type="email" name="email" placeholder="Ej: correo@ejemplo.com" required>
                    </div>
                    <div class="form-group">
                        <label><i class="fas fa-phone me-2"></i>Teléfono</label>
                        <input type="tel" name="telefono" placeholder="Ej: 0987654321" required>
                    </div>
                </div>

                <!-- CUENTA DE USUARIO -->
                <h6 style="margin-top: 30px; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                    <i class="fas fa-lock me-2"></i>Contraseña de Acceso
                </h6>

                <div class="form-group">
                    <label><i class="fas fa-key me-2"></i>Contraseña</label>
                    <input type="password" name="password" placeholder="Mín. 8 caracteres, mayúscula, minúscula, número y símbolo" minlength="8" required>
                    <small class="hint">Debe incluir mayúscula, minúscula, número y símbolo (ej: Yantzaza#2026).</small>
                </div>

                <!-- ARCHIVO DE CREDENCIAL -->
                <h6 style="margin-top: 30px; margin-bottom: 15px; color: #1f2937; font-weight: 700;">
                    <i class="fas fa-file-pdf me-2"></i>Credencial / Nombramiento (opcional)
                </h6>

                <div class="form-group">
                    <label><i class="fas fa-file-pdf me-2"></i>Credencial / Nombramiento (PDF o Imagen)</label>
                    <div class="file-upload">
                        <label for="credencial" class="file-input-label">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <div>Haz clic o arrastra tu archivo aquí</div>
                            <small>(PDF, JPG, PNG – Máx. 5MB, opcional)</small>
                            <div class="file-name" id="file-name"></div>
                        </label>
                        <input type="file" name="credencial" id="credencial" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                </div>

                <button type="submit" class="btn-submit" id="btnSubmit">
                    <i class="fas fa-paper-plane me-2"></i>Crear cuenta de Asesor
                </button>

            </form>

        </div>
    </div>
</div>

<script src="js/validaciones.js"></script>
<script>
// ── Activar validaciones (sin campo 'usuario' en este form) ──
document.addEventListener('DOMContentLoaded', () => {
    bindValidaciones('form');
});

// Manejo del file upload
const fileInput = document.getElementById('credencial');
const fileLabel = document.querySelector('.file-input-label');
const fileName = document.getElementById('file-name');

fileLabel.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', function(e) {
    const file = this.files[0];
    if (file) {
        const maxSize = 5 * 1024 * 1024; // 5MB
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];

        if (!allowedTypes.includes(file.type)) {
            fileName.textContent = '❌ Tipo de archivo no permitido (PDF, JPG, PNG)';
            fileName.classList.add('show');
            this.value = '';
            return;
        }

        if (file.size > maxSize) {
            fileName.textContent = '❌ Archivo muy grande (máx. 5MB)';
            fileName.classList.add('show');
            this.value = '';
            return;
        }

        fileName.textContent = '✅ ' + file.name;
        fileName.classList.add('show');
    }
});

fileLabel.addEventListener('dragover', (e) => {
    e.preventDefault();
    fileLabel.style.background = 'rgba(255, 255, 255, 0.1)';
    fileLabel.style.borderColor = '#667eea';
});

fileLabel.addEventListener('dragleave', () => {
    fileLabel.style.background = 'rgba(102, 126, 234, 0.05)';
    fileLabel.style.borderColor = 'rgba(102, 126, 234, 0.5)';
});

fileLabel.addEventListener('drop', (e) => {
    e.preventDefault();
    fileLabel.style.background = 'rgba(102, 126, 234, 0.05)';
    fileLabel.style.borderColor = 'rgba(102, 126, 234, 0.5)';

    const files = e.dataTransfer.files;
    if (files.length > 0) {
        fileInput.files = files;
        const event = new Event('change', { bubbles: true });
        fileInput.dispatchEvent(event);
    }
});

// ============================================================
// Selector de rol: Gerente General / Supervisor / Asesor
// ============================================================
const roleLabels = {
    gerente_general: { titulo: 'Gerente General', boton: 'Crear cuenta de Gerente General' },
    supervisor:      { titulo: 'Supervisor',       boton: 'Crear cuenta de Supervisor' },
    asesor:          { titulo: 'Asesor',           boton: 'Crear cuenta de Asesor' },
};

function seleccionarRol(rol) {
    document.getElementById('rolCrearInput').value = rol;

    document.querySelectorAll('.role-tab').forEach(tab => {
        tab.classList.toggle('active', tab.dataset.rol === rol);
    });

    const seccionGerente = document.getElementById('seccionGerente');
    const seccionSupervisor = document.getElementById('seccionSupervisor');
    const selectGerente = document.getElementById('selectGerente');
    const selectSupervisor = document.getElementById('selectSupervisor');

    // Gerente General: no necesita ni gerente responsable ni supervisor.
    // Supervisor: necesita elegir el Gerente Responsable (para resolver su agencia).
    // Asesor: necesita elegir el Supervisor al que reporta.
    seccionGerente.style.display = (rol === 'supervisor') ? 'block' : 'none';
    seccionSupervisor.style.display = (rol === 'asesor') ? 'block' : 'none';

    selectGerente.required = (rol === 'supervisor');
    selectSupervisor.required = (rol === 'asesor');

    document.getElementById('btnSubmit').innerHTML =
        '<i class="fas fa-paper-plane me-2"></i>' + roleLabels[rol].boton;

    // Recarga el select correspondiente por si ya había una cooperativa elegida
    onCooperativaChange();
}

document.querySelectorAll('.role-tab').forEach(tab => {
    tab.addEventListener('click', () => seleccionarRol(tab.dataset.rol));
});

// ============================================================
// Cargar gerentes o supervisores según cooperativa + rol elegido
// ============================================================
async function onCooperativaChange() {
    const rol = document.getElementById('rolCrearInput').value;
    const cooperativaId = document.getElementById('selectCooperativa').value;

    if (rol === 'supervisor') {
        await cargarGerentes(cooperativaId);
    } else if (rol === 'asesor') {
        await cargarSupervisores(cooperativaId);
    }
}

async function cargarGerentes(cooperativaId) {
    const select = document.getElementById('selectGerente');
    if (!cooperativaId) {
        select.innerHTML = '<option value="">-- Primero selecciona una cooperativa --</option>';
        return;
    }
    select.innerHTML = '<option value="">Cargando gerentes…</option>';
    try {
        const res = await fetch(`api_gerentes_por_coop.php?cooperativa_id=${encodeURIComponent(cooperativaId)}`);
        const data = await res.json();
        const gerentes = data.gerentes || [];
        if (gerentes.length === 0) {
            select.innerHTML = '<option value="">-- No hay gerentes en esta cooperativa todavía --</option>';
            return;
        }
        let html = '<option value="">-- Selecciona un gerente --</option>';
        gerentes.forEach(g => {
            html += `<option value="${g.id_usuario}">${g.nombre} (${g.email})</option>`;
        });
        select.innerHTML = html;
    } catch (e) {
        select.innerHTML = '<option value="">Error al cargar gerentes</option>';
    }
}

async function cargarSupervisores(cooperativaId) {
    const select = document.getElementById('selectSupervisor');
    if (!cooperativaId) {
        select.innerHTML = '<option value="">-- Primero selecciona una cooperativa --</option>';
        return;
    }
    select.innerHTML = '<option value="">Cargando supervisores…</option>';
    select.disabled = true;
    try {
        const formData = new FormData();
        formData.append('cooperativa_id', cooperativaId);
        const response = await fetch('api_supervisores_por_cooperativa.php', { method: 'POST', body: formData });
        const data = await response.json();

        if (data.status === 'success' && data.supervisores && data.supervisores.length > 0) {
            let html = '<option value="">-- Selecciona un supervisor --</option>';
            data.supervisores.forEach(supervisor => {
                html += `<option value="${supervisor.id}">${supervisor.nombre} (${supervisor.email})</option>`;
            });
            select.innerHTML = html;
        } else {
            select.innerHTML = '<option value="">No hay supervisores en esta cooperativa</option>';
        }
        select.disabled = false;
    } catch (error) {
        console.error('Error cargando supervisores:', error);
        select.innerHTML = '<option value="">Error al cargar supervisores</option>';
        select.disabled = false;
    }
}

// Estado inicial: rol Asesor ya activo por defecto
seleccionarRol('asesor');
</script>

</body>
</html>
