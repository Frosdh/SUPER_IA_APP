<?php
require_once 'db_admin.php';

function _nuevoUuid(): string {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

// Misma lógica que administrar_solicitudes_admin.php: resuelve el id de
// cooperativa guardado en una solicitud (UUID real de unidad_bancaria, o
// "seps_123" del catastro SEPS) a un unidad_bancaria.id real, creando una
// fila espejo si hace falta.
function resolverUnidadBancariaIdSup(PDO $pdo, string $idCooperativa): ?string {
    $idCooperativa = trim($idCooperativa);
    if ($idCooperativa === '') return null;

    if (strpos($idCooperativa, 'seps_') === 0) {
        $sepsId = substr($idCooperativa, 5);
        $stSeps = $pdo->prepare('SELECT * FROM seps_cooperativas WHERE id = ? LIMIT 1');
        $stSeps->execute([$sepsId]);
        $seps = $stSeps->fetch(PDO::FETCH_ASSOC);
        if (!$seps) return null;

        $codigo = 'SEPS-' . $seps['id'];
        $stExiste = $pdo->prepare('SELECT id FROM unidad_bancaria WHERE codigo = ? LIMIT 1');
        $stExiste->execute([$codigo]);
        $existente = $stExiste->fetchColumn();
        if ($existente) return (string)$existente;

        $nuevoId = _nuevoUuid();
        $stIns = $pdo->prepare('INSERT INTO unidad_bancaria (id, nombre, codigo, descripcion, activo) VALUES (?, ?, ?, ?, 1)');
        $stIns->execute([$nuevoId, $seps['razon_social'], $codigo, $seps['direccion'] ?? null]);
        return $nuevoId;
    }

    $stChk = $pdo->prepare('SELECT id FROM unidad_bancaria WHERE id = ? LIMIT 1');
    $stChk->execute([$idCooperativa]);
    $found = $stChk->fetchColumn();
    return $found ? (string)$found : null;
}

// Encuentra (o crea) una agencia "por defecto" para una cooperativa que
// todavía no tiene ninguna agencia registrada. Necesaria porque
// supervisor.jefe_agencia_id es NOT NULL y jefe_agencia.agencia_id también
// lo es -- sin esto, un gerente_general (a cargo de TODA la cooperativa, sin
// agencias creadas todavía) no podía tener supervisores aprobados debajo.
function resolverAgenciaPrincipalSup(PDO $pdo, string $unidadBancariaId): string {
    $st = $pdo->prepare("SELECT id FROM agencia WHERE unidad_bancaria_id = ? ORDER BY id LIMIT 1");
    $st->execute([$unidadBancariaId]);
    $ag = $st->fetchColumn();
    if ($ag) return (string)$ag;

    $st = $pdo->prepare("SELECT nombre FROM unidad_bancaria WHERE id = ? LIMIT 1");
    $st->execute([$unidadBancariaId]);
    $nombreCoop = $st->fetchColumn() ?: 'Cooperativa';

    // Los nombres reales de cooperativa (sobre todo del catastro SEPS) pueden
    // ser larguísimos ("COOPERATIVA DE AHORRO Y CREDITO DEL SINDICATO DE
    // CHOFERES PROFESIONALES DEL CANTON YANTZAZA") y desbordar columnas
    // nombre VARCHAR angostas de zona/agencia -- se recorta agresivo.
    $nombreCoopCorto = mb_substr((string)$nombreCoop, 0, 30);
    $nombreZona = mb_substr('Zona - ' . $nombreCoopCorto, 0, 45);

    // zona.ciudad suele ser NOT NULL en este esquema; se usa un valor
    // genérico ('N/D') si no hay dato de ciudad disponible, en vez de
    // fallar la creación de la agencia por falta de ese dato.
    $zonaId = _nuevoUuid();
    try {
        $pdo->prepare("INSERT INTO zona (id, nombre, ciudad) VALUES (?, ?, ?)")
            ->execute([$zonaId, $nombreZona, 'N/D']);
    } catch (\Throwable $e) {
        // Reintento mínimo por si la columna ciudad no existe/es distinta
        $pdo->prepare("INSERT INTO zona (id, nombre) VALUES (?, ?)")
            ->execute([$zonaId, $nombreZona]);
    }

    $agenciaId = _nuevoUuid();
    try {
        $pdo->prepare("INSERT INTO agencia (id, zona_id, unidad_bancaria_id, nombre, ciudad, direccion, activo) VALUES (?, ?, ?, ?, ?, ?, 1)")
            ->execute([$agenciaId, $zonaId, $unidadBancariaId, 'Agencia Principal', 'N/D', 'N/D']);
    } catch (\Throwable $e) {
        // Reintento mínimo si alguna de esas columnas no existe en este host
        $pdo->prepare("INSERT INTO agencia (id, zona_id, unidad_bancaria_id, nombre, activo) VALUES (?, ?, ?, ?, 1)")
            ->execute([$agenciaId, $zonaId, $unidadBancariaId, 'Agencia Principal']);
    }
    return $agenciaId;
}

// Resuelve supervisor.jefe_agencia_id (NOT NULL) a partir del "gerente
// responsable" elegido en la solicitud. Tres casos:
//   1) El responsable ya es un jefe_agencia real -> se usa directo.
//   2) El responsable es un gerente_general (a cargo de toda la cooperativa,
//      sin agencia puntual todavía) -> se crea/reusa una "Agencia Principal"
//      para su cooperativa y se lo registra también como jefe_agencia de esa
//      agencia (una persona puede ser gerente_general Y jefe_agencia a la vez;
//      son tablas de perfil distintas sobre el mismo usuario).
//   3) No hay responsable resoluble -> se usa la cooperativa de la propia
//      solicitud para crear/reusar la Agencia Principal, pero sin un usuario
//      dueño no se puede crear el jefe_agencia -> devuelve null (el llamador
//      debe pedir que se asigne un gerente antes de aprobar).
function resolverJefeAgenciaIdSup(PDO $pdo, ?string $idAdministrador, string $idCooperativaSolicitud): ?string {
    if (!empty($idAdministrador)) {
        $st = $pdo->prepare('SELECT id FROM jefe_agencia WHERE usuario_id = ? LIMIT 1');
        $st->execute([$idAdministrador]);
        $ja = $st->fetchColumn();
        if ($ja) return (string)$ja;

        $st = $pdo->prepare('SELECT unidad_bancaria_id FROM gerente_general WHERE usuario_id = ? LIMIT 1');
        $st->execute([$idAdministrador]);
        $ubId = $st->fetchColumn();
        if ($ubId) {
            $agenciaId = resolverAgenciaPrincipalSup($pdo, (string)$ubId);
            $nuevoJaId = _nuevoUuid();
            $pdo->prepare('INSERT INTO jefe_agencia (id, usuario_id, agencia_id) VALUES (?, ?, ?)')
                ->execute([$nuevoJaId, $idAdministrador, $agenciaId]);
            return $nuevoJaId;
        }
    }
    return null;
}

// Verificar sesión del admin
$is_admin = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
$is_super_admin = isset($_SESSION['super_admin_logged_in']) && $_SESSION['super_admin_logged_in'] === true;

if (!$is_admin && !$is_super_admin) {
    header('Location: login.php?role=admin');
    exit;
}

$admin_id = $is_super_admin ? $_SESSION['super_admin_id'] : $_SESSION['admin_id'];
$admin_nombre = $is_super_admin ? $_SESSION['super_admin_nombre'] : $_SESSION['admin_nombre'];

// Procesar aprobación/rechazo de solicitudes
$mensaje_exito = '';
$mensaje_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_solicitud = $_POST['id_solicitud'] ?? null;
    $accion = $_POST['accion'] ?? null;
    $observaciones = $_POST['observaciones'] ?? '';

    if ($id_solicitud && $accion) {
        try {
            // Si la solicitud llegó sin gerente asignado (el solicitante lo
            // dejó opcional), el administrador puede elegirlo aquí mismo al
            // aprobar/rechazar, vía el selector "gerente_asignar" del modal.
            $gerente_asignar = trim($_POST['gerente_asignar'] ?? '');
            if ($gerente_asignar !== '') {
                try {
                    $stmtGA = $pdo->prepare("UPDATE solicitudes_supervisor SET id_administrador = ? WHERE id_solicitud = ? AND (id_administrador IS NULL OR id_administrador = '')");
                    $stmtGA->execute([$gerente_asignar, $id_solicitud]);
                } catch (Exception $e) {}
            }

            if ($accion === 'aprobar') {
                // Crear tabla si no existe
                $pdo->exec("
                    CREATE TABLE IF NOT EXISTS solicitudes_supervisor (
                        id_solicitud INT AUTO_INCREMENT PRIMARY KEY,
                        id_cooperativa VARCHAR(36) NOT NULL,
                        id_administrador VARCHAR(64) NOT NULL,
                        usuario VARCHAR(50) NOT NULL UNIQUE,
                        cedula VARCHAR(13) NULL,
                        nombres VARCHAR(100) NOT NULL,
                        apellidos VARCHAR(100) NOT NULL,
                        email VARCHAR(100) NOT NULL UNIQUE,
                        password_hash VARCHAR(255) NOT NULL,
                        telefono VARCHAR(20) NOT NULL,
                        credencial_archivo VARCHAR(255) NULL,
                        estado ENUM('pendiente', 'aprobada', 'rechazada') DEFAULT 'pendiente',
                        fecha_solicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        fecha_aprobacion TIMESTAMP NULL,
                        observaciones TEXT NULL
                    )
                ");

                // Verificar si la columna credencial_archivo existe, si no agregarla
                $stmt = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'credencial_archivo'");
                if (!$stmt->fetch()) {
                    $pdo->exec("ALTER TABLE solicitudes_supervisor ADD COLUMN credencial_archivo VARCHAR(255) NULL AFTER telefono");
                }

                // Verificar si la columna cedula existe, si no agregarla
                $stmt = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'cedula'");
                if (!$stmt->fetch()) {
                    $pdo->exec("ALTER TABLE solicitudes_supervisor ADD COLUMN cedula VARCHAR(13) NULL AFTER usuario");
                }

                // Obtener datos de la solicitud
                $stmt = $pdo->prepare("SELECT * FROM solicitudes_supervisor WHERE id_solicitud = ? AND estado = 'pendiente'");
                $stmt->execute([$id_solicitud]);
                $solicitud = $stmt->fetch();

                if ($solicitud) {
                    // Validar permisos: Si es admin, solo puede procesar sus propias solicitudes
                    if (!$is_super_admin && $solicitud['id_administrador'] != $admin_id) {
                        $mensaje_error = "❌ No tienes permiso para procesar esta solicitud.";
                    } else {
                        // Nota: antes esto insertaba en una tabla `usuarios` (plural,
                        // con columnas clave/nombres/id_rol_fk) que no existe en este
                        // esquema — la consulta fallaba con un 1146 y la solicitud
                        // nunca creaba la cuenta real. La tabla real es `usuario`
                        // (singular, UUID), igual que en la aprobación de gerentes y
                        // asesores. `usuario` no tiene columna `cedula`; ese dato se
                        // queda solo en `solicitudes_supervisor` para referencia.
                        $chkEmail = $pdo->prepare("SELECT id FROM usuario WHERE email = ? LIMIT 1");
                        $chkEmail->execute([$solicitud['email']]);
                        if ($chkEmail->fetch()) {
                            $mensaje_error = "❌ Ya existe un usuario con ese email.";
                        } else {
                            $pdo->beginTransaction();
                            try {
                                $nombre_completo = trim($solicitud['nombres'] . ' ' . $solicitud['apellidos']);
                                $nuevo_usuario_id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                                    mt_rand(0, 0xffff),
                                    mt_rand(0, 0x0fff) | 0x4000,
                                    mt_rand(0, 0x3fff) | 0x8000,
                                    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
                                );

                                $stmtUsr = $pdo->prepare("
                                    INSERT INTO usuario
                                        (id, nombre, email, telefono, password_hash, rol, activo, estado_aprobacion, aprobado_por, fecha_aprobacion)
                                    VALUES (?, ?, ?, ?, ?, 'supervisor', 1, 'aprobado', ?, NOW())
                                ");
                                $stmtUsr->execute([
                                    $nuevo_usuario_id,
                                    $nombre_completo,
                                    $solicitud['email'],
                                    $solicitud['telefono'],
                                    $solicitud['password_hash'],
                                    $admin_id,
                                ]);

                                // supervisor.jefe_agencia_id es NOT NULL: hay que resolver
                                // (o crear) el jefe_agencia real detrás del "gerente
                                // responsable" elegido al aprobar. Ver resolverJefeAgenciaIdSup()
                                // arriba: si el responsable es un gerente_general de toda la
                                // cooperativa (como en este caso), se crea/reusa una "Agencia
                                // Principal" y se lo registra ahí también como jefe_agencia.
                                $jefeAgenciaId = resolverJefeAgenciaIdSup($pdo, $solicitud['id_administrador'] ?: null, (string)$solicitud['id_cooperativa']);
                                if (!$jefeAgenciaId) {
                                    throw new \Exception('No se pudo asignar una agencia/jefe de agencia para esta solicitud. Asigna un "Gerente Responsable" antes de aprobar.');
                                }

                                $nuevo_sup_id = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                                    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                                    mt_rand(0, 0xffff),
                                    mt_rand(0, 0x0fff) | 0x4000,
                                    mt_rand(0, 0x3fff) | 0x8000,
                                    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
                                );
                                $stmtSup = $pdo->prepare("
                                    INSERT INTO supervisor (id, usuario_id, jefe_agencia_id, meta_asesores)
                                    VALUES (?, ?, ?, 5)
                                ");
                                $stmtSup->execute([$nuevo_sup_id, $nuevo_usuario_id, $jefeAgenciaId]);

                                // Actualizar solicitud como aprobada
                                $stmt = $pdo->prepare("
                                    UPDATE solicitudes_supervisor
                                    SET estado = 'aprobada', fecha_aprobacion = NOW()
                                    WHERE id_solicitud = ?
                                ");
                                $stmt->execute([$id_solicitud]);

                                $pdo->commit();
                                $mensaje_exito = "✅ Solicitud aprobada. El nuevo supervisor puede iniciar sesión.";
                            } catch (\Throwable $eTx) {
                                $pdo->rollBack();
                                $mensaje_error = "Error al aprobar: " . $eTx->getMessage();
                            }
                        }
                    }
                }
            } elseif ($accion === 'rechazar') {
                // Obtener datos de la solicitud para validar permisos
                $stmt = $pdo->prepare("SELECT * FROM solicitudes_supervisor WHERE id_solicitud = ? AND estado = 'pendiente'");
                $stmt->execute([$id_solicitud]);
                $solicitud = $stmt->fetch();

                if ($solicitud) {
                    // Validar permisos: Si es admin, solo puede procesar sus propias solicitudes
                    if (!$is_super_admin && $solicitud['id_administrador'] != $admin_id) {
                        $mensaje_error = "❌ No tienes permiso para procesar esta solicitud.";
                    } else {
                        // Actualizar como rechazada
                        $stmt = $pdo->prepare("
                            UPDATE solicitudes_supervisor 
                            SET estado = 'rechazada', observaciones = ?, fecha_aprobacion = NOW()
                            WHERE id_solicitud = ?
                        ");
                        $stmt->execute([$observaciones, $id_solicitud]);
                        $mensaje_exito = "❌ Solicitud rechazada.";
                    }
                } else {
                    $mensaje_error = "❌ Solicitud no encontrada.";
                }
            }
        } catch (Exception $e) {
            $mensaje_error = "Error: " . $e->getMessage();
        }
    }
}

// Crear tabla si no existe
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS solicitudes_supervisor (
            id_solicitud INT AUTO_INCREMENT PRIMARY KEY,
            id_cooperativa VARCHAR(36) NOT NULL,
            id_administrador VARCHAR(64) NOT NULL,
            usuario VARCHAR(50) NOT NULL UNIQUE,
            cedula VARCHAR(13) NULL,
            nombres VARCHAR(100) NOT NULL,
            apellidos VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            telefono VARCHAR(20) NOT NULL,
            credencial_archivo VARCHAR(255) NULL,
            estado ENUM('pendiente', 'aprobada', 'rechazada') DEFAULT 'pendiente',
            fecha_solicitud TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            fecha_aprobacion TIMESTAMP NULL,
            observaciones TEXT NULL
        )
    ");

    // Verificar si la columna credencial_archivo existe, si no agregarla
    $stmt = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'credencial_archivo'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE solicitudes_supervisor ADD COLUMN credencial_archivo VARCHAR(255) NULL AFTER telefono");
    }

    // Verificar si la columna cedula existe, si no agregarla
    $stmt = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'cedula'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE solicitudes_supervisor ADD COLUMN cedula VARCHAR(13) NULL AFTER usuario");
    }

    // Corregir tipo de id_administrador / id_cooperativa si la tabla ya
    // existía como INT. El gerente y la cooperativa reales son UUID
    // (VARCHAR), no un entero: si estas columnas se crearon como INT en
    // algún momento, MySQL truncaba/convertía ese UUID a un número al
    // guardar la solicitud, y luego "WHERE id_administrador = ..." (con el
    // UUID de la sesión) nunca coincidía — por eso el gerente no veía las
    // solicitudes de supervisor que le correspondían.
    $colInfo = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'id_administrador'")->fetch(PDO::FETCH_ASSOC);
    if ($colInfo && stripos($colInfo['Type'], 'int') !== false) {
        $pdo->exec("ALTER TABLE solicitudes_supervisor MODIFY COLUMN id_administrador VARCHAR(64) NOT NULL DEFAULT ''");
    }
    $colInfo = $pdo->query("SHOW COLUMNS FROM solicitudes_supervisor LIKE 'id_cooperativa'")->fetch(PDO::FETCH_ASSOC);
    if ($colInfo && stripos($colInfo['Type'], 'int') !== false) {
        $pdo->exec("ALTER TABLE solicitudes_supervisor MODIFY COLUMN id_cooperativa VARCHAR(36) NOT NULL DEFAULT ''");
    }
} catch (Exception $e) {}

// Obtener solicitudes de supervisores
$solicitudes = [];
try {
    // LEFT JOIN a usuario para mostrar el nombre del gerente asignado (si
    // ya tiene uno) — id_administrador ahora puede llegar vacío porque el
    // gerente responsable es opcional en el formulario de registro.
    $query = "SELECT ss.*, u_ger.nombre AS gerente_nombre
              FROM solicitudes_supervisor ss
              LEFT JOIN usuario u_ger ON u_ger.id = ss.id_administrador ";
    $params = [];

    // Si es admin (no super admin), solo ver sus propias solicitudes o las
    // que aún no tienen gerente asignado (para poder tomarlas).
    // id_administrador es un UUID (VARCHAR) — antes se usaba intval($admin_id),
    // que truncaba el UUID a 0 y nunca traía resultados.
    if (!$is_super_admin && $is_admin) {
        $query .= "WHERE (ss.id_administrador = ? OR ss.id_administrador = '' OR ss.id_administrador IS NULL) ";
        $params[] = $admin_id;
    }

    $query .= "ORDER BY
            CASE estado
                WHEN 'pendiente' THEN 1
                WHEN 'rechazada' THEN 2
                WHEN 'aprobada' THEN 3
            END,
            fecha_solicitud DESC
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $solicitudes = $stmt->fetchAll();
} catch (Exception $e) {}

$currentPage = 'solicitudes_supervisor';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super_IA - Solicitudes de Supervisores</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --brand-yellow: #ffdd00; --brand-navy: #123a6d; --brand-navy-deep: #0a2748;
            --brand-border: #d7e0ea; --brand-bg: #f4f6f9; --brand-shadow: 0 16px 34px rgba(18,58,109,.08);
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter','Segoe UI',sans-serif; background: linear-gradient(180deg,#f8fafc 0%,var(--brand-bg) 100%); display: flex; height: 100vh; color: var(--brand-navy-deep); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 24px; }
        .stat-card { background: #fff; padding: 22px 20px; border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,.06); text-align: center; border: 1px solid var(--brand-border); }
        .stat-card .number { font-size: 34px; font-weight: 800; }
        .stat-card .label { color: #9ca3af; font-size: 13px; margin-top: 5px; font-weight: 500; }
        .alert-success { background: #ecfdf5; border: 1px solid #a7f3d0; color: #065f46; padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; }
        .alert-danger  { background: #fef2f2; border: 1px solid #fecaca; color: #991b1b; padding: 12px 16px; border-radius: 10px; margin-bottom: 20px; }
        .table-card { background: #fff; border-radius: 16px; box-shadow: var(--brand-shadow); overflow: hidden; border: 1px solid var(--brand-border); }
        .table-card .card-header-custom { padding: 18px 22px; border-bottom: 1px solid var(--brand-border); }
        .table-card h6 { font-weight: 700; margin: 0; font-size: 16px; color: var(--brand-navy-deep); }
        .table { margin-bottom: 0; }
        .table thead th { background: #f4f6f9; font-size: 11px; text-transform: uppercase; color: #6c757d; border: none; padding: 13px 14px; letter-spacing: .4px; }
        .table tbody td { padding: 13px 14px; vertical-align: middle; border-color: #f0f4f8; font-size: 13.5px; }
        .table tbody tr:hover { background: #f8fafc; }
        .badge-pendiente { background: #fef08a; color: #713f12; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 12px; }
        .badge-aprobada  { background: #dcfce7; color: #166534; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 12px; }
        .badge-rechazada { background: #fee2e2; color: #991b1b; padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 12px; }
        .btn-aprobar  { background: #10b981; color: #fff; border: none; padding: 6px 13px; border-radius: 7px; cursor: pointer; font-size: 12px; font-weight: 700; }
        .btn-aprobar:hover  { background: #059669; }
        .btn-rechazar { background: #ef4444; color: #fff; border: none; padding: 6px 13px; border-radius: 7px; cursor: pointer; font-size: 12px; font-weight: 700; }
        .btn-rechazar:hover { background: #dc2626; }
        .sol-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.45); align-items: center; justify-content: center; z-index: 1050; }
        .sol-modal.show { display: flex; }
        .sol-modal-box { background: #fff; border-radius: 16px; padding: 2rem; max-width: 520px; width: 92%; box-shadow: 0 24px 48px rgba(0,0,0,.18); }
        .sol-modal-box h5 { margin: 0 0 1.2rem; font-weight: 800; color: var(--brand-navy-deep); font-size: 18px; }
        .sol-modal-box textarea { width: 100%; padding: 10px 14px; border: 1.5px solid #e5e7eb; border-radius: 9px; font-family: inherit; resize: vertical; font-size: 13.5px; margin-top: 10px; }
        .sol-modal-footer { display: flex; gap: 10px; justify-content: flex-end; margin-top: 1.4rem; }
        .sol-modal-footer button { padding: 9px 20px; border-radius: 9px; border: none; cursor: pointer; font-weight: 700; font-size: 14px; }
        .btn-confirm { background: linear-gradient(135deg,var(--brand-navy-deep),var(--brand-navy)); color: #fff; }
        .btn-cancel  { background: #e5e7eb; color: #374151; }
        .page-title { font-size: 26px; font-weight: 800; color: var(--brand-navy-deep); margin-bottom: 4px; }
        .page-sub   { font-size: 14px; color: #64748b; margin-bottom: 22px; }
    </style>
</head>
<body>

<?php
$alertas_pendientes = 0;
require_once '_sidebar_gerente.php';
?>

    <div style="padding: 30px; padding-bottom: 40px;">

        <a href="mis_supervisores.php" style="display:inline-flex;align-items:center;gap:8px;padding:8px 18px;background:rgba(18,58,109,.08);color:#0a2748;border:1.5px solid #d7e0ea;border-radius:10px;text-decoration:none;font-weight:600;font-size:13.5px;margin-bottom:14px;transition:background .2s;" onmouseover="this.style.background='rgba(18,58,109,.15)'" onmouseout="this.style.background='rgba(18,58,109,.08)'">
            <i class="fas fa-arrow-left"></i> Volver a Mis Supervisores
        </a>
        <div class="page-title"><i class="fas fa-clipboard-list me-2"></i>Solicitudes de Supervisores</div>
        <p class="page-sub">Revisa y gestiona las solicitudes de registro de supervisores.</p>

        <?php if ($mensaje_exito): ?>
        <div class="alert-success">
            <i class="fas fa-check-circle me-2"></i><?php echo $mensaje_exito; ?>
        </div>
        <?php endif; ?>

        <?php if ($mensaje_error): ?>
        <div class="alert-danger">
            <i class="fas fa-exclamation-circle me-2"></i><?php echo $mensaje_error; ?>
        </div>
        <?php endif; ?>

        <!-- ESTADÍSTICAS -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="number" style="color: #fbbf24;">
                    <?php echo count(array_filter($solicitudes, fn($s) => $s['estado'] === 'pendiente')); ?>
                </div>
                <div class="label">Pendientes</div>
            </div>
            <div class="stat-card">
                <div class="number" style="color: #10b981;">
                    <?php echo count(array_filter($solicitudes, fn($s) => $s['estado'] === 'aprobada')); ?>
                </div>
                <div class="label">Aprobadas</div>
            </div>
            <div class="stat-card">
                <div class="number" style="color: #ef4444;">
                    <?php echo count(array_filter($solicitudes, fn($s) => $s['estado'] === 'rechazada')); ?>
                </div>
                <div class="label">Rechazadas</div>
            </div>
        </div>

        <!-- FILTROS DE BÚSQUEDA -->
        <div class="filter-bar" style="background: #fff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 14px 18px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap; margin-bottom: 20px; box-shadow: 0 4px 16px rgba(0,0,0,.04);">
            <i class="fas fa-search" style="color:#6b7280;"></i>
            <input type="text" id="busquedaSolicitud" placeholder="Buscar por nombre o email..." style="min-width:260px; flex:1; padding:9px 14px; border:1.5px solid #e2e8f0; border-radius:9px; font-size:14px; outline:none; transition: border-color 0.2s;" onfocus="this.style.borderColor='#fbbf24'" onblur="this.style.borderColor='#e2e8f0'">
            <div style="display:flex; gap:8px; flex-wrap:wrap;">
                <button type="button" class="btn-filter active" data-status="todos" style="padding:7px 14px;border:1.5px solid #e2e8f0;border-radius:8px;background:#fff;font-size:12.5px;font-weight:700;cursor:pointer;">Todos</button>
                <button type="button" class="btn-filter" data-status="pendiente" style="padding:7px 14px;border:1.5px solid #fbbf2433;border-radius:8px;background:#fff;font-size:12.5px;font-weight:700;cursor:pointer;">Pendientes</button>
                <button type="button" class="btn-filter" data-status="aprobada" style="padding:7px 14px;border:1.5px solid #10b98133;border-radius:8px;background:#fff;font-size:12.5px;font-weight:700;cursor:pointer;">Aprobadas</button>
                <button type="button" class="btn-filter" data-status="rechazada" style="padding:7px 14px;border:1.5px solid #ef444433;border-radius:8px;background:#fff;font-size:12.5px;font-weight:700;cursor:pointer;">Rechazadas</button>
            </div>
            <span id="cntResultados" style="font-size:13px; color:#6b7280; margin-left:auto;"><?php echo count($solicitudes); ?> resultados</span>
        </div>
        <style>
            .btn-filter.active { background: var(--brand-navy-deep) !important; color: #fff !important; border-color: var(--brand-navy-deep) !important; }
        </style>

        <!-- TABLA DE SOLICITUDES -->
        <div class="table-card">
            <div class="card-header-custom">
                <h6><i class="fas fa-list me-2"></i>Listado de Solicitudes</h6>
            </div>
            <div style="overflow-x: auto;">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Cédula</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Gerente</th>
                            <th>Credencial</th>
                            <th>Estado</th>
                            <th>Fecha Solicitud</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($solicitudes)): ?>
                        <tr>
                            <td colspan="9" style="text-align: center; color: #9ca3af; padding: 30px;">
                                <i class="fas fa-inbox me-2"></i>No hay solicitudes
                            </td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($solicitudes as $solicitud):
                                // Credencial: verificar en disco (is_file) igual que en
                                // solicitudes de asesor, para no mostrar "Ver Credencial"
                                // si el archivo en realidad no existe ahí.
                                $credSup = $solicitud['credencial_archivo'] ?? '';
                                $credSupPath = '';
                                $credSupExiste = false;
                                if (!empty($credSup)) {
                                    $rutaFisicaSup = __DIR__ . '/../../uploads/supervisor_credentials/' . basename($credSup);
                                    if (is_file($rutaFisicaSup)) {
                                        $credSupExiste = true;
                                        $credSupPath = '../../uploads/supervisor_credentials/' . basename($credSup);
                                    }
                                }
                            ?>
                            <tr data-search-status="<?php echo htmlspecialchars($solicitud['estado']); ?>">
                                <td><strong><?php echo htmlspecialchars($solicitud['usuario']); ?></strong></td>
                                <td><?php echo htmlspecialchars($solicitud['cedula'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($solicitud['nombres'] . ' ' . $solicitud['apellidos']); ?></td>
                                <td><?php echo htmlspecialchars($solicitud['email']); ?></td>
                                <td>
                                    <?php if (!empty($solicitud['gerente_nombre'])): ?>
                                    <?php echo htmlspecialchars($solicitud['gerente_nombre']); ?>
                                    <?php else: ?>
                                    <span style="color:#9ca3af;font-size:12px;font-style:italic;">Sin asignar</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($credSupExiste): ?>
                                    <a href="<?php echo htmlspecialchars($credSupPath); ?>"
                                       target="_blank"
                                       style="color: #3182fe; text-decoration: none; font-weight: 600;">
                                        <i class="fas fa-file-pdf me-1"></i>Ver Credencial
                                    </a>
                                    <?php elseif (!empty($credSup)): ?>
                                    <span style="color: #9ca3af; font-size: 12px;">
                                        <i class="fas fa-exclamation-triangle me-1"></i>Credencial no encontrada
                                    </span>
                                    <?php else: ?>
                                    <span style="color: #9ca3af; font-size: 12px;">
                                        <i class="fas fa-file-circle-xmark me-1"></i>Sin credencial
                                    </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge-<?php echo $solicitud['estado']; ?>">
                                        <?php echo ucfirst($solicitud['estado']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d/m/Y H:i', strtotime($solicitud['fecha_solicitud'])); ?></td>
                                <td>
                                    <?php if ($solicitud['estado'] === 'pendiente'): ?>
                                    <button class="btn-aprobar" onclick="mostrarModal('aprobar', <?php echo $solicitud['id_solicitud']; ?>, '<?php echo $credSupExiste ? htmlspecialchars(addslashes($credSupPath)) : ''; ?>', '<?php echo htmlspecialchars(addslashes($solicitud['id_cooperativa'])); ?>', <?php echo empty($solicitud['id_administrador']) ? 'true' : 'false'; ?>)">
                                        <i class="fas fa-check me-1"></i>Aprobar
                                    </button>
                                    <button class="btn-rechazar" onclick="mostrarModal('rechazar', <?php echo $solicitud['id_solicitud']; ?>, '<?php echo $credSupExiste ? htmlspecialchars(addslashes($credSupPath)) : ''; ?>')" style="margin-left: 5px;">
                                        <i class="fas fa-times me-1"></i>Rechazar
                                    </button>
                                    <?php else: ?>
                                    <span style="color: #9ca3af; font-size: 12px;">Procesada</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div><!-- /.inner padding -->
</div><!-- /.content-area -->
</div><!-- /.main-content -->

<!-- MODAL SOLICITUD -->
<div id="solModal" class="sol-modal">
    <div class="sol-modal-box">
        <h5 id="solModalTitle">Confirmar</h5>
        <form id="solModalForm" method="POST">
            <input type="hidden" name="id_solicitud" id="input-solicitud">
            <input type="hidden" name="accion" id="input-accion">
            <div id="modal-body-content"></div>
            <div id="gerente-asignar-wrap" style="display:none;margin-top:12px;">
                <label style="font-size:13px;font-weight:700;color:#374151;display:block;margin-bottom:6px;">
                    <i class="fas fa-user-cog me-1"></i>Esta solicitud no tiene gerente asignado — elige uno (opcional):
                </label>
                <select name="gerente_asignar" id="gerente_asignar" style="width:100%;padding:9px 12px;border:1.5px solid #e5e7eb;border-radius:9px;font-size:13.5px;">
                    <option value="">-- Dejar sin asignar --</option>
                </select>
            </div>
            <textarea id="observaciones" name="observaciones" placeholder="Observaciones (opcional)..." style="display:none;"></textarea>
            <div class="sol-modal-footer">
                <button type="button" class="btn-cancel" onclick="cerrarModal()">Cancelar</button>
                <button type="submit" class="btn-confirm" id="btn-confirmar">Confirmar</button>
            </div>
        </form>
    </div>
</div>

<script>
function mostrarModal(accion, id, credencial, coopId, sinGerente) {
    const modal = document.getElementById('solModal');
    const title = document.getElementById('solModalTitle');
    const inputSolicitud = document.getElementById('input-solicitud');
    const inputAccion = document.getElementById('input-accion');
    const modalBody = document.getElementById('modal-body-content');
    const observaciones = document.getElementById('observaciones');
    const btnConfirmar = document.getElementById('btn-confirmar');
    const gerenteWrap = document.getElementById('gerente-asignar-wrap');
    const gerenteSelect = document.getElementById('gerente_asignar');

    inputSolicitud.value = id;
    inputAccion.value = accion;

    // Si la solicitud no tiene gerente asignado, ofrecer elegirlo aquí
    // mismo (es opcional: se puede aprobar igual dejándolo sin asignar).
    if (accion === 'aprobar' && sinGerente && coopId) {
        gerenteWrap.style.display = 'block';
        gerenteSelect.innerHTML = '<option value="">Cargando gerentes…</option>';
        fetch(`api_gerentes_por_coop.php?cooperativa_id=${encodeURIComponent(coopId)}`)
            .then(res => res.json())
            .then(data => {
                gerenteSelect.innerHTML = '<option value="">-- Dejar sin asignar --</option>';
                (data.gerentes || []).forEach(ger => {
                    const option = document.createElement('option');
                    option.value = ger.id_usuario;
                    option.textContent = ger.nombre + ' (' + ger.email + ')';
                    gerenteSelect.appendChild(option);
                });
            })
            .catch(() => {
                gerenteSelect.innerHTML = '<option value="">-- Dejar sin asignar --</option>';
            });
    } else {
        gerenteWrap.style.display = 'none';
        gerenteSelect.value = '';
    }

    let modalHTML = '';
    
    if (accion === 'aprobar') {
        title.textContent = 'Aprobar Solicitud';
        modalHTML = '<p>¿Estás seguro de que deseas <strong>aprobar</strong> esta solicitud?</p><p style="color: #9ca3af; font-size: 13px;">El supervisor podrá iniciar sesión inmediatamente.</p>';
        observaciones.style.display = 'none';
        btnConfirmar.textContent = 'Aprobar';
        btnConfirmar.className = 'btn-primary-modal';
    } else {
        title.textContent = 'Rechazar Solicitud';
        modalHTML = '<p>¿Estás seguro de que deseas <strong>rechazar</strong> esta solicitud?</p>';
        observaciones.style.display = 'block';
        btnConfirmar.textContent = 'Rechazar';
        btnConfirmar.className = 'btn-primary-modal';
        btnConfirmar.style.background = '#ef4444';
    }
    
    // Agregar sección de credencial.
    // "credencial" ya llega como la ruta relativa VERIFICADA en el servidor
    // (is_file() ya confirmó que el archivo existe ahí); si no se pudo
    // confirmar, llega vacío y se muestra el aviso de "no disponible".
    if (credencial) {
        modalHTML += '<hr style="margin: 15px 0; border: none; border-top: 1px solid #e5e7eb;">';
        modalHTML += '<p style="margin-bottom: 10px; color: #6c757d; font-size: 13px;"><strong>Credencial:</strong></p>';
        const ext = credencial.split('.').pop().toLowerCase();
        if (ext === 'pdf') {
            modalHTML += '<embed src="' + credencial + '" type="application/pdf" style="width: 100%; height: 300px; border: 1px solid #e5e7eb; border-radius: 6px;">';
        } else {
            modalHTML += '<img src="' + credencial + '" style="max-width: 100%; max-height: 300px; border: 1px solid #e5e7eb; border-radius: 6px;">';
        }
        modalHTML += '<p style="margin-top: 10px;"><a href="' + credencial + '" target="_blank" style="color: #3182fe; text-decoration: none; font-size: 12px;"><i class="fas fa-download me-1"></i>Descargar archivo</a></p>';
    } else {
        modalHTML += '<hr style="margin: 15px 0; border: none; border-top: 1px solid #e5e7eb;">';
        modalHTML += '<p style="color: #fbbf24; font-size: 12px;"><i class="fas fa-exclamation-triangle me-1"></i>⚠️ No hay credencial disponible</p>';
    }
    
    modalBody.innerHTML = modalHTML;
    modal.classList.add('show');
}

function cerrarModal() {
    document.getElementById('solModal').classList.remove('show');
}

// Lógica de búsqueda + filtro por estado en la tabla
document.addEventListener('DOMContentLoaded', function() {
    const inputBusqueda = document.getElementById('busquedaSolicitud');
    const cntResultados = document.getElementById('cntResultados');
    const filterButtons = document.querySelectorAll('.btn-filter');
    let currentStatus = 'todos';

    function aplicarFiltros() {
        const term = inputBusqueda ? inputBusqueda.value.toLowerCase().trim() : '';
        const filas = document.querySelectorAll('.table tbody tr:not(.empty-row)');
        let visibles = 0;

        filas.forEach(fila => {
            // Si la fila es la de "No hay solicitudes", la ignoramos
            if (fila.querySelector('td[colspan]')) return;

            const estado = (fila.dataset.searchStatus || '').toLowerCase();
            const usuario = fila.querySelector('td:nth-child(1)').textContent.toLowerCase();
            const cedula = fila.querySelector('td:nth-child(2)').textContent.toLowerCase();
            const nombre = fila.querySelector('td:nth-child(3)').textContent.toLowerCase();
            const email = fila.querySelector('td:nth-child(4)').textContent.toLowerCase();

            const matchBusq = !term || usuario.includes(term) || cedula.includes(term) || nombre.includes(term) || email.includes(term);
            const matchFilt = currentStatus === 'todos' || estado === currentStatus;

            if (matchBusq && matchFilt) {
                fila.style.display = '';
                visibles++;
            } else {
                fila.style.display = 'none';
            }
        });

        if (cntResultados) cntResultados.textContent = visibles + (visibles === 1 ? ' resultado' : ' resultados');

        let emptyRow = document.querySelector('.empty-row');
        if (visibles === 0 && filas.length > 0) {
            if (!emptyRow) {
                const tbody = document.querySelector('.table tbody');
                const tr = document.createElement('tr');
                tr.className = 'empty-row';
                tr.innerHTML = '<td colspan="8" style="text-align:center;padding:32px 0;color:#9ca3af;"><i class="fas fa-search" style="font-size:28px;display:block;margin-bottom:10px;opacity:.4;"></i>No hay solicitudes que coincidan con el filtro.</td>';
                tbody.appendChild(tr);
            }
        } else {
            if (emptyRow) emptyRow.remove();
        }
    }

    if (inputBusqueda) inputBusqueda.addEventListener('input', aplicarFiltros);

    filterButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            filterButtons.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentStatus = this.dataset.status || 'todos';
            aplicarFiltros();
        });
    });
});

document.getElementById('solModalForm').onsubmit = function(e) {
    e.preventDefault();
    this.submit();
};

document.getElementById('solModal').onclick = function(e) {
    if (e.target === this) cerrarModal();
};
</script>

</body>
</html>
