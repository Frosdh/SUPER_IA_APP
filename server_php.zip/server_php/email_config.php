<?php
// ============================================================
// email_config.php — Credenciales SMTP para PHPMailer
// El sistema intenta Gmail primero, luego el SMTP del hosting.
// ============================================================

return [
    // ── Remitente — DEBE coincidir con el username del SMTP activo ─────────────
    'from_email' => 'edwinchoez83@gmail.com',   // ← igual que username Gmail
    'from_name'  => 'Super_IA',

    // ── SMTP principal: Gmail ──────────────────────────────────────────────────
    // Contraseña de aplicación (16 chars) en: https://myaccount.google.com/apppasswords
    'host'       => 'smtp.gmail.com',
    'port'       => 587,
    'secure'     => 'tls',
    'username'   => 'edwinchoez83@gmail.com',
    'password'   => 'abzudapfzcsjkeoz',   // App Password actualizada 2026-06-08

    // ── SMTP de respaldo: hosting corporativoqbank.com ─────────────────────────
    // Se usa automáticamente si Gmail falla (hosting bloquea puerto 587).
    // Rellena 'fallback_password' con la contraseña real del buzón.
    'fallback_host'     => 'mail.corporativoqbank.com',
    'fallback_port'     => 465,
    'fallback_secure'   => 'ssl',
    'fallback_username' => 'angelespinozav@corporativoqbank.com',
    'fallback_password' => '',   // ← pon aquí la password del buzón del hosting
    'fallback_from'     => 'angelespinozav@corporativoqbank.com',
];
