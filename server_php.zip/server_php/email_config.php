<?php
// ============================================================
// email_config.php  —  Credenciales SMTP para PHPMailer
//
// OPCIÓN A: Gmail SMTP  (recomendado — llega a cualquier correo)
//   host     → smtp.gmail.com
//   port     → 587
//   secure   → tls
//   username → tu_correo@gmail.com
//   password → Contraseña de aplicación de Google (16 letras sin espacios)
//               NO uses tu contraseña normal de Gmail.
//               Genera una en: https://myaccount.google.com/apppasswords
//               (Necesitas tener activada la verificación en 2 pasos)
//
// OPCIÓN B: Servidor del hosting corporativoqbank.com
//   host     → mail.corporativoqbank.com
//   port     → 465
//   secure   → ssl
//   username → angelespinozav@corporativoqbank.com
//   password → La contraseña real del buzón de correo
// ============================================================

return [
    // ── Elige OPCIÓN A (Gmail) o OPCIÓN B (hosting) ──────────

    // OPCIÓN A — Gmail SMTP
    'host'       => 'smtp.gmail.com',
    'port'       => 587,
    'secure'     => 'tls',
    'username'   => 'edwinchoez83@gmail.com',
    'password'   => 'grzukkxkbhsdcetr',
    'from_email' => 'edwinchoez83@gmail.com',
    'from_name'  => 'Super_IA',

    // ── OPCIÓN B — Hosting (comenta la A y descomenta la B) ──
    // 'host'       => 'mail.corporativoqbank.com',
    // 'port'       => 465,
    // 'secure'     => 'ssl',
    // 'username'   => 'angelespinozav@corporativoqbank.com',
    // 'password'   => 'LA_PASSWORD_REAL_DEL_BUZÓN',
    // 'from_email' => 'angelespinozav@corporativoqbank.com',
    // 'from_name'  => 'Super_IA',
];


// ============================================================