<?php
echo "Server Time: " . date("Y-m-d H:i:s") . "\n";
echo "Timestamp: " . time() . "\n";
?>
