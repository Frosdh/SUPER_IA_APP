<?php
return [
    'host' => 'mail.corporativoqbank.com',
    'port' => 465,
    'secure' => 'ssl',
    'username' => 'angelespinozav@corporativoqbank.com',
    'password' => 'Maria123*.1',
    'from_email' => 'angelespinozav@corporativoqbank.com',
    'from_name' => 'Fuber',
];
